// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
var DB = null;

angular.module('starter', ['ionic', 'starter.controllers', 'ngCordova', 'starter.factories', 'starter.services'])

.run(function($ionicPlatform, $cordovaSQLite) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
    DB = window.openDatabase("rssnow.db", "1.0", "rssnow", -1);
    $cordovaSQLite.execute(DB, "CREATE TABLE IF NOT EXISTS fontes (id integer primary key, url text, nome text not null);");
  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })

    .state('app.eventos', {
    url: '/eventos',
    views: {
      'menuContent': {
        templateUrl: 'templates/eventos.html'
      }
    } 
  })

  .state('app.consultas', {
    url: '/consultas',
    views: {
      'menuContent': {
        templateUrl: 'templates/consultas.html'
      }
    } 
  })   

    .state('app.exames', {
    url: '/exames',
    views: {
      'menuContent': {
        templateUrl: 'templates/exames.html'
      }
    } 
  })   

    .state('app.remedios', {
    url: '/remedios',
    views: {
      'menuContent': {
        templateUrl: 'templates/remedios.html'
      }
    } 
  })       

  .state('app.rss', {
    url: '/rss',
    views: {
      'menuContent': {
        templateUrl: 'templates/rss.html'
      }
    }
  })

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'AppCtrl'
  })

  .state('app.cadastro_remedio', {
    url: '/cadastro_remedio',
    views: {
      'menuContent': {
        templateUrl: 'templates/cadastro_remedio.html'
      }
    }
  })

  .state('app.cadastro_consulta', {
    url: '/cadastro_consulta',
    views: {
      'menuContent': {
        templateUrl: 'templates/cadastro_consulta.html'
      }
    }
  })
  ;
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/login');
});
