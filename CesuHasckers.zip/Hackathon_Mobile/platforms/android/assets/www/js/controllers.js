angular.module('starter.controllers', [])

.controller("AppCtrl", function($rootScope, $scope, $state, $ionicModal, RssFactory, $ionicPlatform, $ionicPopup, $ionicHistory, $ionicSideMenuDelegate, $window, RssService, AppService){
  $scope.serverIp = "http://172.20.255.150:3000/api";


  $scope.showMenu = function() {
     $ionicSideMenuDelegate.toggleLeft();
     $scope.refreshData();
  };

  $scope.converterData = function(data){
    return moment(data).fromNow();
  };
  $scope.verLocal = function(local){
     $window.open(local, "_system");
  };

  $scope.converterDataConsulta = function(data){
    return moment(data).format("dddd, DD/MM - HH:mm");
  };


  $scope.converterDataRemedio = function(data){
    return moment(data).format("HH:mm");
  };

  $scope.toggleEvento = function(evento){
    if (evento.show){
      evento.show = !evento.show;
    } else {
      evento.show = true;
    }
  };

  $scope.refreshData = function(callback){
    
   /* { //TODO REMOVER ESSA DESGRinha
      AppService.login("1", "1").then(function(res2){
        $rootScope.usuario = res2.data[0];
        $scope.refreshData();
      });
    }*/
      console.log("REFRESHING");
     if ($rootScope.usuario._id){
        console.log($rootScope.usuario);
        AppService.getEventosMes().then(
          function(res){
            $rootScope.eventos = res.data;
            AppService.getConsultas($rootScope.usuario._id).then(
              function(res){
                $rootScope.consultas = res.data;
                AppService.getExames($rootScope.usuario._id).then(
                  function(res){
                    $rootScope.exames = res.data;
                    AppService.getRemedios($rootScope.usuario._id).then(
                      function(res){
                        $rootScope.remedios = res.data;
                        $scope.printData();
                        if(callback){callback();}
                      });
                  });
              });
          }); 
    }
  };

  $scope.printData = function(){
   /* console.log($rootScope.consultas);
    console.log($rootScope.eventos);
    console.log($rootScope.remedios);
    console.log($rootScope.exames);*/
  };

  $scope.realizarLogin = function(){
    AppService.login($scope.login.cartao, $scope.login.cpf).then(function(res2){
      $rootScope.usuario = res2.data[0];
      $state.go("app.rss");
    });
  };

  $scope.cadastroRemedios = function(remedio){
    AppService.createRemedios($rootScope.usuario._id, "", remedio).then(function(res2){
      remedio = res2;
      $scope.refreshData(function(){$state.go("app.remedios");});
    });
  };

  $scope.cadastroConsulta = function(consulta){
    AppService.createConsulta($rootScope.usuario._id, "", consulta).then(function(res2){
      consulta = res2;
      //$scope.refreshData(function(){$state.go("app.cadastro_consulta");});
      $scope.refreshData(function(){$state.go("app.consultas");});
    });
  };

  $scope.cancelarConsulta = function(consulta){
    consulta.cancelada = true;
    AppService.updateConsulta(consulta).then(function(res2){
      consulta = res2;
    });
  };  

  $ionicPlatform.ready(function(){
    
  });
});