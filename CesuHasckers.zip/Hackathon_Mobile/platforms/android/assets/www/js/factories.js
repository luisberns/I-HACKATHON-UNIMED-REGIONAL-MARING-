angular.module("starter.factories", [])

.factory("RssFactory", function($cordovaSQLite, $q){
	return {
		salvarFonte : function(fonte){
			var query = "";
			var parameters = [];
			if (!fonte.id){
				query = "INSERT INTO fontes (url, nome) VALUES (?, ?);";
				parameters = [fonte.url, fonte.nome];
			} else {
				query = "UPDATE fontes SET url=?, nome=? WHERE id=?;"
				parameters = [fonte.url, fonte.nome, fonte.id];
			}
			return $cordovaSQLite.execute(DB, query, parameters);
		},
		listarFontes : function(){
			var query = "SELECT * FROM fontes";
			var q = $q.defer();
			$cordovaSQLite.execute(DB, query).then(function(result){
				var output = [];
				for (var i = 0; i < result.rows.length; i++){
					output.push(result.rows.item(i));
				}
				q.resolve(output);
			})
			return q.promise;
		},
		removerFonte : function(fonte){
			var query = "DELETE FROM fontes WHERE id=?";
			var parameters = [fonte.id];
			return $cordovaSQLite.execute(DB, query, parameters);
		}		
	}
});