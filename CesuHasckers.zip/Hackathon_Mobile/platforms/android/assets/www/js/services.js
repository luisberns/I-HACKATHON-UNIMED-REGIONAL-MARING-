angular.module("starter.services", [])


.service("AppService", function($http){
	return {
		getEventosMes : function(){
			return $http.get("http://172.20.255.150:3000/api" + "/eventos");
		},
		getConsultas : function(id,token){
			return $http.get("http://172.20.255.150:3000/api" + "/consultas_by_beneficiario_nao_canceladas/" + encodeURIComponent(id));
		},		
		getExames : function(id,token){
			return $http.get("http://172.20.255.150:3000/api" + "/exames_by_beneficiario_id/" + encodeURIComponent(id));
		},
		getRemedios : function(id,token){
			return $http.get("http://172.20.255.150:3000/api" + "/remedios_a_tomar_by_beneficiario_id/" + encodeURIComponent(id));
		},
		createRemedios : function(id,token,remedio){
			remedio.beneficiario_id = id;
			console.log(remedio.horario);
			return $http.post("http://172.20.255.150:3000/api" + "/remedio_a_tomar", remedio, {header:{"Content-Type":"application/json"}});
		},
		createConsulta : function(id,token,consulta){
			console.log("teste cadastro consulta");
			consulta.beneficiario_id = id;
			consulta.medico_id = "1";
			return $http.post("http://172.20.255.150:3000/api" + "/consulta", consulta, {header:{"Content-Type":"application/json"}});
		},

		login : function(cartao, cpf){
			return $http.post("http://172.20.255.150:3000/api" + "/login", {
					cpf : cpf,
					cartao : cartao
			},
			{
					headers:{"Content-Type" : "application/json"}
			});
		},



		updateConsulta : function(consulta){
			console.log("H");
			return $http.put("http://172.20.255.150:3000/api" + "/consulta/" + encodeURIComponent(consulta._id), 
				consulta,

			{
					headers:{"Content-Type" : "application/json"}
			});
		}	

	}
})

.service("RssService", function($http){
	return {
		getAll : function(url){
			console.log("http://ajax.googleapis.com/ajax/services/feed/load"+"?v=1.0&num=50&callback=JSON_CALLBACK&q="+encodeURIComponent(url));
			return $http.jsonp("http://ajax.googleapis.com/ajax/services/feed/load"+"?v=1.0&num=50&callback=JSON_CALLBACK&q="+encodeURIComponent(url));
		}
	}
});